﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Expression;
using Microsoft.Expression.Encoder.ScreenCapture;

namespace ScreenRecorder
{
    public partial class Form1 : Form
    {
        public int i=0;
        public Form1()
        {
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        public MemoryStream storeStream = new MemoryStream();
        private Bitmap Get_Screen()
        {
            Size s = Screen.PrimaryScreen.Bounds.Size;
            Bitmap bt = new Bitmap(s.Width, s.Height);
            Graphics g = Graphics.FromImage(bt);
            g.CopyFromScreen(0, 0, 0, 0, s);
            //bt.Save("d:\\myBitmap"+i.ToString()+".bmp");
            //i++;
            
            //FileStream inStream = File.OpenRead("c:\\text.txt");
            bt.Save(storeStream, System.Drawing.Imaging.ImageFormat.Jpeg);
            
            return bt;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Image = Get_Screen();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            FileStream file = new FileStream("d:\\rec.mp4", FileMode.Create, System.IO.FileAccess.Write);
            byte[] bytes = new byte[storeStream.Length];
            storeStream.Read(bytes, 0, (int)storeStream.Length);
            file.Write(bytes, 0, bytes.Length);
            file.Close();
            storeStream.Close();
        }
    }
}
