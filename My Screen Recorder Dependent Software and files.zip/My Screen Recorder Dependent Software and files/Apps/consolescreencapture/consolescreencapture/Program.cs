﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Expression.Encoder;
using Microsoft.Expression.Encoder.ScreenCapture;
using System.Drawing;
using Microsoft.Expression.Encoder.Devices;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.Globalization;

namespace consolescreencapture
{
    class Program
    {
        static void Main(string[] args)
        {
            string date = "2013-03-25";
            DateTime datebefor1day = DateTime.Parse(date);
            DateTime now = DateTime.Now;
            Console.WriteLine("BeforDay: " + datebefor1day.ToString() + " Now:" + now.ToString());
            if (now < datebefor1day)
            {
                //Console.WriteLine("Befor1Day: " + datebefor1day.ToString() + " Now:" + now.ToString());
                RecordScreensV1();
            }
            else
            {
                Console.WriteLine("Sorry demo has been expired.");
            }
            //string namedt = String.Format("{0:F}", DateTime.Now).Replace(':', '.');
            //Console.WriteLine(namedt);
            //string namefromdate = DateTime.Now.ToString("d MMM YYYY", CultureInfo.CreateSpecificCulture("en-US")) + DateTime.Now.ToLongTimeString().Replace(':','.');
            //Console.WriteLine(namefromdate);
            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();
            ////RecordScreens();
            //RecordScreensV1();
        }

        private static void RecordScreensV1()
        {
            // Creates new job
            using (ScreenCaptureJob job = new ScreenCaptureJob())
            {
                // Sets the top right coordinates of the capture rectangle
                int topRightX = 0;
                int topRightY = 0;
                // Sets the bottom left coordinates of the capture rectangle
                int BottomLeftX = topRightX + 300;
                int BottomLeftY = topRightY + 150;
                Rectangle rect =  Screen.PrimaryScreen.WorkingArea;
                job.CaptureRectangle = rect;//new Rectangle(topRightX, topRightY, BottomLeftX, BottomLeftY);
                job.ShowFlashingBoundary = true;
                Collection<EncoderDevice> audioDevices = EncoderDevices.FindDevices(EncoderDeviceType.Audio);
                //audioDevices.First(delegate(EncoderDevice item) { return item.Name.StartsWith(@"Speakers"); });
                EncoderDevice foundDevice = audioDevices[0];
                job.AddAudioDeviceSource(foundDevice);
                job.OutputPath = @"c:\output_new_next";
                ////job.OutputScreenCaptureFileName = @"c:\output_new\myrecording" + DateTime.Now.Millisecond.ToString() + ".wmv";

                string namedt = String.Format("{0:F}", DateTime.Now).Replace(':', '.');
                job.OutputScreenCaptureFileName = @"c:\output_new_next\Screen Recording on " + namedt + ".wmv";

                job.Start();
                Console.WriteLine("Press 'x'to stop recording.");
                while (Console.ReadKey(true).Key != ConsoleKey.X) ;
                Console.WriteLine("Recordingstopped.");
                job.Stop();
            }
        }

        private static void RecordScreens()
        {

            // Creates new job
            using (ScreenCaptureJob job = new ScreenCaptureJob())
            {
                // Sets the top right coordinates of the capture rectangle
                int topRightX = 0;
                int topRightY = 0;
                // Sets the bottom left coordinates of the capture rectangle
                int BottomLeftX = topRightX + 300;
                int BottomLeftY = topRightY + 150;
                Rectangle rect = Screen.PrimaryScreen.WorkingArea;
                job.CaptureRectangle = rect;//new Rectangle(topRightX, topRightY, BottomLeftX, BottomLeftY);
                job.ShowFlashingBoundary = true;
                Collection<EncoderDevice> audioDevices = EncoderDevices.FindDevices(EncoderDeviceType.Audio);
                //audioDevices.First(delegate(EncoderDevice item) { return item.Name.StartsWith(@"Speakers"); });
                EncoderDevice foundDevice = audioDevices[0];
                job.AddAudioDeviceSource(foundDevice);
                job.OutputPath = @"C:\Users\om\Desktop\Current";

                job.Start();

                Console.WriteLine("Press 'x'to stop recording.");
                while (Console.ReadKey(true).
                Key != ConsoleKey.X) ;
                Console.WriteLine("Recordingstopped.");
                job.Stop();

            }
        }
    }
}