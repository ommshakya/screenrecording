﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Expression.Encoder;
using Microsoft.Expression.Encoder.ScreenCapture;
using System.Drawing;
using Microsoft.Expression.Encoder.Devices;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.Globalization;


namespace recorderwithreferences
{
    class Program
    {
        static void Main(string[] args)
        {
            RecordScreensV1();
        }

        private static void RecordScreensV1()
        {
            // Creates new job
            using (ScreenCaptureJob job = new ScreenCaptureJob())
            {
                // Sets the top right coordinates of the capture rectangle
                int topRightX = 0;
                int topRightY = 0;
                // Sets the bottom left coordinates of the capture rectangle
                int BottomLeftX = topRightX + 300;
                int BottomLeftY = topRightY + 150;
                Rectangle rect = Screen.PrimaryScreen.WorkingArea;
                job.CaptureRectangle = rect;//new Rectangle(topRightX, topRightY, BottomLeftX, BottomLeftY);
                job.ShowFlashingBoundary = true;
                Collection<EncoderDevice> audioDevices = EncoderDevices.FindDevices(EncoderDeviceType.Audio);
                //audioDevices.First(delegate(EncoderDevice item) { return item.Name.StartsWith(@"Speakers"); });
                EncoderDevice foundDevice = audioDevices[0];
                job.AddAudioDeviceSource(foundDevice);
                job.OutputPath = @"c:\output_new_next";
                ////job.OutputScreenCaptureFileName = @"c:\output_new\myrecording" + DateTime.Now.Millisecond.ToString() + ".wmv";

                string namedt = String.Format("{0:F}", DateTime.Now).Replace(':', '.');
                job.OutputScreenCaptureFileName = @"c:\output_new_next\Screen Recording on " + namedt + ".wmv";

                job.Start();
                Console.WriteLine("Press 'x'to stop recording.");
                while (Console.ReadKey(true).Key != ConsoleKey.X) ;
                Console.WriteLine("Recordingstopped.");
                job.Stop();
            }
        }
    }
}
